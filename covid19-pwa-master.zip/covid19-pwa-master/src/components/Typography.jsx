import Typography from '@material-ui/core/Typography'

export default Typography